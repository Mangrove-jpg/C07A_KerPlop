Names: Stephen Carmon, Joyce Zhou
Section: CSCI306B
Sources: w3schools.com for ArrayList syntax, geeksforgeeks.org for information about java.util.Random class and on how to declare/instantiate an array in Java